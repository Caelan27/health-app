class Tile:
    def __init__(self, entity):
        self.entity = entity
