from game.core.tile import Tile
from game.entities.empty import Empty
from game.entities.player import Player
from game.entities.enemy import Enemy
from game.entities.items import Item
from game.entities.creature import Creature
from game.core.entity_factory import EntityFactory
from kivy.properties import NumericProperty
from kivy.properties import BooleanProperty
from kivy.event import EventDispatcher
from random import randint


class GameState(EventDispatcher):
    """
    A subclass of EventDispatcher to handle most of the game's logic.

    Attributes:
        curr_player_health (NumericProperty):
            Stores the player's current health
        max_player_health (NumericProperty):
            Stores the player's maximum health
        player_speed (NumericProperty):
            Stores the player's speed
        player_attack_damage (NumericProperty):
            Stores the player's attack damage
        game_over (BooleanProperty):
            Stores whether or not the game is finished

        width (int):
            The number of columns on the screen
        height (int):
            The number of rows on the screen
        grid (list[list[Tile]]):
            Stores the tiles on the screen, displayed in a grid
        current_actor (Entity):
            Stores the entity whose turn it is currently
        entity_factory (EntityFactory):
            An EntityFactory used to create entities
        player (Entity):
            The player entity
        enemy_spawn_timer (int):
            The number of turns until a new enemy will spawn
        item_spawn_timer (int):
            The number of turns until a new item will spawn
    """

    curr_player_health = NumericProperty()
    max_player_health = NumericProperty()
    player_speed = NumericProperty()
    player_attack_damage = NumericProperty()
    score = NumericProperty(0)

    game_over = BooleanProperty(False)

    def __init__(self, width, height):
        """
        Initialises the GameState.

        Args:
            width (int):
                The number of columns in the screen
            height (int):
                The number of rows in the screen

        Actions:
            - Initialises self.width and self.height
            - Creates an empty grid
            - Sets the current actor to None
            - Creates an EntityFactory
            - Create the player at the position (0, 0)
            - Start enemy and item spawn timers
            - Sync the player stats from the player entity
        """
        super().__init__()

        self.width = width
        self.height = height

        self.grid = []

        self.current_actor = None

        self.entity_factory = EntityFactory()

        self.player = self.entity_factory.create_player((0, 0))

        self.enemy_spawn_timer = randint(5, 20)
        self.item_spawn_timer = randint(5, 20)

        self.curr_player_health = self.player.curr_health
        self.max_player_health = self.player.max_health
        self.player_speed = self.player.speed
        self.player_attack_damage = self.player.attack_damage


    def initialise_grid(self):
        """
        Initialises the grid.

        Actions:
            - Adds the correct number of buttons to the grid
            - Adds the player to the grid
            - Gives the player a function to sync its stats
            - Adds an item to the grid
            - Adds an enemy to the grid
            - Starts the game by advancing time
        """
        for y in range(self.height):
            self.grid.append([])
            for x in range(self.width):
                self.grid[y].append(Tile(Empty()))

        (player_x, player_y) = self.player.position
        self.grid[player_y][player_x].entity = self.player

        self.player.on_stats_changed = self._sync_stats_from_player

        self.spawn_item()

        self.spawn_enemy()

        self.advance_time()

    def move_creature(self, creature, destination):
        """
        Moves a creature entity to another position.

        Args:
            - creature (Entity):
                The entity to be moved
            - destination (tuple[int, int]):
                The position to move to

        Actions:
            - Checks the destination is within the grid
            - Checks the destination is empty
            - Changes the entity of the destination tile to the creature
            - Updates the creature's position attribute
            - Makes the creature's original position empty

        Returns:
            - boolean:
                True if the creature successfully moved, False if not
        """
        (origin_x, origin_y) = creature.position
        (destination_x, destination_y) = destination

        if not self.in_bounds(destination):
            return False

        if not isinstance(self.grid[destination_y][destination_x].entity, Empty):
            return False

        self.grid[destination_y][destination_x].entity = creature
        creature.position = destination
        self.grid[origin_y][origin_x].entity = Empty()

        return True

    def _sync_stats_from_player(self):
        """
        Syncs the player's stats.

        Actions:
            - Goes through each stat, giving the NumericProperty in this class the value of the player's int attribute
        """
        self.curr_player_health = self.player.curr_health
        self.max_player_health = self.player.max_health
        self.player_speed = self.player.speed
        self.player_attack_damage = self.player.attack_damage

    def interact_with_tile(self, tile_location):
        """
        Handles the player trying to interact with a tile.

        Args:
            - tile_location (tuple[int, int]):
                The position of the tile the player tried to interact with

        Actions:
            - Checks that it is the player's turn
            - Goes through each entity type and decides the action based on it.
                If it's Empty, the player should move there.
                If it's an Item, the player should use that item.
                If it's a Creature, the player should attack the creature
            - If the player did something:
                - Handle the player's stat decay
                - Handle the end of turn operations.
        """

        (tile_x, tile_y) = tile_location
        tile = self.grid[tile_y][tile_x]
        entity = tile.entity

        did_something = False
        if self.current_actor == self.player:
            if isinstance(entity, Empty):
                did_something = self.move_player(tile_location)
            elif isinstance(entity, Item):
                did_something = self.eat_food(tile_location)
            elif isinstance(entity, Creature):
                did_something = self.attack_creature(
                    self.player, tile_location)

        if did_something:
            self.handle_decay()
            self.end_turn()

    def enemy_turn(self):
        """
        Performs the enemy's turn.

        Actions:
            - Makes the enemy take a turn
            - Handle the end of turn operations
        """
        self.current_actor.take_turn(self.player, self)
        self.end_turn()

    def handle_decay(self):
        """
        Handles the player's stat decay.

        Actions:
            - Decays the players stats
            - Decreases the countdowns on the player's decay wearing out
        """
        self.player.decay()
        self.player.decay_countdown()

    def end_turn(self):
        """
        Handles end of turn operations.

        Actions:
            - Decreases the turn meter of the entity that took a turn
            - Resets the current actor
            - If the player died, handle their death
            - Remove any dead entities from the grid
            - Decrease the enemy and item spawn timers
            - Spawn an enemy / item and reset the timer if they ran out
            - Advance time
        """
        actor = self.current_actor

        if actor is not None:
            actor.turn_meter -= 100

        self.current_actor = None

        if not self.player.is_alive:
            self.handle_player_death()

        self.remove_dead()

        self.enemy_spawn_timer -= 1
        if self.enemy_spawn_timer == 0:
            self.spawn_enemy()
            self.enemy_spawn_timer = randint(5, 20)

        self.item_spawn_timer -= 1
        if self.item_spawn_timer == 0:
            self.spawn_item()
            self.item_spawn_timer = randint(5, 20)

        self.advance_time()

    def spawn_enemy(self):
        """
        Spawns a random enemy in a random position on the grid

        Actions:
            - Keeps looping until an enemy is spawned
            - Chooses a random position on the grid
            - If the space is empty, create an enemy in that position
        """
        spawned = False

        while not spawned:
            (enemy_x, enemy_y) = (randint(0, 4), randint(0, 4))
            entity = self.grid[enemy_y][enemy_x].entity
            if isinstance(entity, Empty):
                enemy = self.entity_factory.random_enemy((enemy_x, enemy_y))
                enemy.adjust_stats(self.score)
                self.grid[enemy_y][enemy_x].entity = enemy
                spawned = True

    def spawn_item(self):
        """
        Spawns a random item in a random position on the grid

        Actions:
            - Keeps looping until an item is spawned
            - Chooses a random position on the grid
            - If the space is empty, create an item in that position
        """
        # TODO: Combine this method with the spawn_enemy one

        spawned = False

        while not spawned:
            (food_x, food_y) = (randint(0, 4), randint(0, 4))
            entity = self.grid[food_y][food_x].entity
            if isinstance(entity, Empty):
                self.grid[food_y][food_x].entity = self.entity_factory.random_item()
                spawned = True

    def handle_player_death(self):
        """
        Handles the player's death.

        Actions:
            - Sets the game_over BooleanProperty to True
        """
        self.game_over = True

    def refresh_grid(self):
        """
        Refreshes the grid.

        Actions:
            - Removes any dead entities from the grid
        """
        self.remove_dead()

    def remove_dead(self):
        """
        Removes dead creatures from the grid

        Actions:
            - Goes through each space in the grid, checking if it is a Creature
            - If it's a creature, check if it's alive
            - If it's not alive, remove it from the grid
        """
        for y in range(self.height):
            for x in range(self.width):
                entity = self.grid[y][x].entity
                if isinstance(entity, Creature):
                    if not entity.is_alive:
                        self.grid[y][x].entity = Empty()

    def advance_time(self):
        """
        Advances time.

        Actions:
            - Keeps looping until something stops it
            - If the player is dead, stop looping
            - Reset the entities who need to take their turns
            - Loop while there is no one who can take their turn:
                - Go through each creature in the grid, updating its turn meter
                - If the turn meter has reached 100, add them to the actors who are ready to take their turns
            - Go through each actor who is ready to take their turn:
                - If it's an enemy, take their turn
                - If it's a player, stop the loop of advancing time to let them take their turn
        """
        while True:
            if not self.player.is_alive:
                break
            ready_actors = []

            while not ready_actors:
                for y in range(self.height):
                    for x in range(self.width):
                        entity = self.grid[y][x].entity
                        if isinstance(entity, Creature):
                            entity.turn_meter += entity.speed
                            if entity.turn_meter >= 100:
                                ready_actors.append(entity)

            for actor in ready_actors:
                self.current_actor = actor
                if isinstance(self.current_actor, Enemy):
                    self.enemy_turn()
                elif isinstance(self.current_actor, Player):
                    # Time will begin advancing again once the player takes their turn
                    return

    def attack_creature(self, attacker, creature_location):
        (creature_x, creature_y) = creature_location
        attacker_position = attacker.position

        if (self.is_adjacent(attacker_position, creature_location)
                and self.in_bounds(creature_location)
                and attacker_position != creature_location):
            tile = self.grid[creature_y][creature_x]
            creature = tile.entity
            attacker.deal_damage(creature)

            return True
        else:
            return False

    def eat_food(self, food_location):
        (food_x, food_y) = food_location
        player_position = self.player.position

        if (self.is_adjacent(player_position, food_location)
                and self.in_bounds(food_location)):
            tile = self.grid[food_y][food_x]
            food = tile.entity
            self.power_up(food)

            tile.entity = Empty()
            return True
        else:
            return False

    def power_up(self, item):
        self.player.max_health += item.max_health_boost
        self.player.speed += item.speed_boost
        self.player.attack_damage += item.attack_boost
        self.player.heal(item.curr_health_boost)

        self.player.attack_damage_decay.append(item.attack_decay)
        self.player.speed_decay.append(item.speed_decay)
        self.player.max_health_decay.append(item.max_health_decay)
        self.player.decay_duration_left.append(item.decay_duration)

        self.score += item.score_boost

        self._sync_stats_from_player()

    def move_player(self, destination):
        player = self.player
        grid = self.grid

        (origin_x, origin_y) = origin = player.position

        (destination_x, destination_y) = destination

        if (self.is_adjacent(origin, destination)
                and self.in_bounds(destination)):
            grid[destination_y][destination_x].entity = player
            player.position = destination

            grid[origin_y][origin_x].entity = Empty()

            return True
        else:
            return False

    def in_bounds(self, position):
        (x, y) = position
        return not (x < 0 or y < 0 or x >= self.width or y >= self.height)

    def is_adjacent(self, a, b):
        (ax, ay) = a
        (bx, by) = b
        dx = abs(bx - ax)
        dy = abs(by - ay)

        return dx <= 1 and dy <= 1
