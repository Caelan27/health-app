class Entity:
    def __init__(self):
        pass
