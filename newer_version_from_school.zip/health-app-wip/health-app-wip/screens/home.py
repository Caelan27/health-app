from kivy.uix.screenmanager import Screen


class HomeScreen(Screen):
    pass
