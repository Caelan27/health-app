import json

with open("data.json", "r") as json_file:
    data = json_file.read()

parsed_data = json.loads(data)
information_pages = parsed_data["information-pages"]
for page in information_pages:
    title = page["title"].upper()
    print(title)
    print()

    image_path = page["img"]
    print("Image path:", image_path)
    print()

    sections = page["sections"]
    for section in sections:
        heading_title = section["heading-title"]

        text = section["text"]

        print(heading_title)
        print(text)
        print()
